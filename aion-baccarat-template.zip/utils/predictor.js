
export function predictNext(result, history, triglock, baccarat) {
  const lastFive = history.slice(-5).join('-');
  let prediction = '⏩';
  let reason = 'ยังไม่พบเค้าไพ่ชัดเจน';

  // ตัวอย่าง logic ง่าย ๆ
  if (lastFive.endsWith('b-b-b')) {
    prediction = 'b';
    reason = 'เค้าไพ่มังกรแดง';
  } else if (lastFive.endsWith('p-b-p')) {
    prediction = 'p';
    reason = 'เค้าไพ่ปิงปอง';
  }

  return {
    prediction,
    confidence: prediction === '⏩' ? 'ต่ำ' : 'สูง',
    reason,
    history: [...history, result]
  };
}
