
# AION BACCARAT (Mobile-Deploy Ready)

ระบบวิเคราะห์บาคาร่าอัตโนมัติ ใช้งานได้ผ่าน Vercel หรือ Replit  
มีระบบทำนายผล / แสดงผลแบบเรียลไทม์

## วิธีใช้งาน
1. นำโปรเจกต์นี้ไปใส่ GitHub หรือ Replit
2. Deploy ขึ้น Vercel ได้ทันที
